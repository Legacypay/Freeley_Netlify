// shared.js - Freeley shared components

const NAV_HTML = (activePage = '') => `
<nav class="nav" id="nav">
  <a href="index.html" class="nav-logo">Freeley<span>.</span></a>
  <div class="nav-links">
    <a href="weight-loss.html" ${activePage === 'weight-loss' ? 'class="active"' : ''}>GLP-1 Weight Loss</a>
    <a href="hormones.html" ${activePage === 'hormones' ? 'class="active"' : ''}>Hormones</a>
    <a href="longevity.html" ${activePage === 'longevity' ? 'class="active"' : ''}>Longevity</a>
    <a href="how-it-works.html" ${activePage === 'how' ? 'class="active"' : ''}>How It Works</a>
    <a href="pricing.html" ${activePage === 'pricing' ? 'class="active"' : ''}>Pricing</a>
  </div>
  <div class="nav-right">
    <a href="#" class="nav-login">Sign In</a>
    <a href="quiz.html" class="nav-cta">Start Free Visit →</a>
  </div>
  <button class="nav-mobile-toggle" onclick="toggleMobileNav()" aria-label="Menu">
    <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
      <path d="M3 6h16M3 11h16M3 16h16" stroke="white" stroke-width="1.8" stroke-linecap="round"/>
    </svg>
  </button>
</nav>
<div class="mobile-nav" id="mobileNav">
  <a href="index.html">Home</a>
  <a href="weight-loss.html">GLP-1 Weight Loss</a>
  <a href="hormones.html">Hormones</a>
  <a href="longevity.html">Longevity</a>
  <a href="how-it-works.html">How It Works</a>
  <a href="pricing.html">Pricing</a>
  <a href="quiz.html" class="mobile-cta">Start Free Visit →</a>
</div>
`;

const FOOTER_HTML = `
<footer>
  <div class="footer-grid">
    <div>
      <div class="footer-brand-logo">Freeley</div>
      <p class="footer-brand-desc">Healthcare technology connecting patients to licensed physicians and compounding pharmacies — on your terms.</p>
      <div class="footer-social">
        <a href="#" title="Instagram">IG</a>
        <a href="#" title="TikTok">TT</a>
        <a href="#" title="X">𝕏</a>
        <a href="#" title="Facebook">FB</a>
      </div>
    </div>
    <div class="footer-col">
      <h4>Treatments</h4>
      <a href="weight-loss.html">GLP-1 Weight Loss</a>
      <a href="hormones.html">Hormone Therapy</a>
      <a href="longevity.html">Longevity & Peptides</a>
      <a href="pricing.html">Pricing</a>
    </div>
    <div class="footer-col">
      <h4>Company</h4>
      <a href="how-it-works.html">How It Works</a>
      <a href="#">About Freeley</a>
      <a href="#">FAQ</a>
      <a href="#">Contact Us</a>
    </div>
    <div class="footer-col">
      <h4>Legal</h4>
      <a href="#">Privacy Policy</a>
      <a href="#">Terms of Service</a>
      <a href="#">HIPAA Notice</a>
      <a href="#">Telehealth Consent</a>
    </div>
  </div>
  <div class="footer-bottom">
    <p class="footer-disclaimer">Freeley is a healthcare technology platform that facilitates connections between patients and independently licensed telemedicine providers and 503A compounding pharmacies. Freeley does not practice medicine, employ physicians, or dispense medications. All treatment decisions are made solely by licensed practitioners. Compounded medications are not FDA-approved. Results vary. Not available in all states. FSA/HSA eligibility varies.</p>
    <div class="footer-copy">© 2025 Freeley Health Technologies, LLC</div>
  </div>
</footer>
`;

const MOBILE_NAV_STYLES = `
.mobile-nav {
  display: none; position: fixed; top: 72px; left: 0; right: 0; z-index: 199;
  background: rgba(7,21,16,0.98); backdrop-filter: blur(20px);
  padding: 24px; flex-direction: column; gap: 4px;
  border-bottom: 1px solid rgba(255,255,255,0.08);
}
.mobile-nav.open { display: flex; }
.mobile-nav a { color: rgba(255,255,255,0.7); text-decoration: none; padding: 12px 16px; border-radius: 10px; font-size: 15px; transition: all 0.2s; }
.mobile-nav a:hover { color: #fff; background: rgba(255,255,255,0.06); }
.mobile-nav .mobile-cta { background: var(--green-light); color: #fff !important; text-align: center; margin-top: 8px; font-weight: 500; }
`;

function toggleMobileNav() {
  document.getElementById('mobileNav').classList.toggle('open');
}

function initPage(activePage) {
  // Inject nav + footer
  document.body.insertAdjacentHTML('afterbegin', NAV_HTML(activePage));
  document.body.insertAdjacentHTML('beforeend', FOOTER_HTML);

  // Mobile nav styles
  const style = document.createElement('style');
  style.textContent = MOBILE_NAV_STYLES;
  document.head.appendChild(style);

  // Scroll reveal
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        setTimeout(() => entry.target.classList.add('visible'), i * 80);
      }
    });
  }, { threshold: 0.08 });
  document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

  // Nav scroll effect
  window.addEventListener('scroll', () => {
    const nav = document.getElementById('nav');
    if (window.scrollY > 40) nav.style.background = 'rgba(7,21,16,0.98)';
    else nav.style.background = 'rgba(7,21,16,0.94)';
  });
}
